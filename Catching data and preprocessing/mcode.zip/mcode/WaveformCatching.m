% In God We Trust
% My name is Reza Sadeghi
% My emails are reza@knoesis.org; sadeghi.2@wright.edu

% This file will downlaod all MIMIC-III waveform subset of matching with numerical output
% Date: 10/13/2017
% Ver:1

clc
clear
close all

[filename, pathname]=uigetfile({'*.*'},'RECORDS-numerics');
Path=[pathname filename];

Nrows = numel(textread(Path,'%1c%*[^\n]'));
fileID = fopen(Path,'r');
ID=zeros(1,Nrows);

i=0;
while ~feof(fileID)
    i=i+1;
    Temp=fgets(fileID);
    Wave(i).address = ['mimic3wdb/matched/' Temp(1:end-1)];
end
fclose(fileID);

%parfor j=1:i
load PureCCUWave.mat
parfor j=1:length(T)
    disp(T(j))
    wfdb2mat(Wave(T(j)).address)
end