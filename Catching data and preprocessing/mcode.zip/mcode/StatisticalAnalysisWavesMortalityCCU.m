% In God We Trust
% My name is Reza Sadeghi
% My emails are reza@knoesis.org; sadeghi.2@wright.edu

% Doing statistical analysis over pure files downlaod from MIMIC-III waveform subset of matching with numerical output
% Date: 11/03/2017
% Ver:7
% For One hour

clc
clear
close all

%% Input the name of whole waives of Matching subset
fileID = fopen('RECORDS-numerics','r');

i=0;
while ~feof(fileID)
    i=i+1;
    Line=fgets(fileID);
    Slash=find(Line=='/',1,'last');
    Wave(i).name = [Line(Slash+1:end-1) 'm'];
end
fclose(fileID);

load PureCCUWave.mat
load Mortality.mat
%sfields=cell(1,length(T));
F=0;
KK=0;
Ignored=0;
MaxFs=1;
Energy=@(x) sum(x.^2)/length(x);
for j=1:length(T)
    disp(T(j))
    Patient=struct;
    %% selecting a wavie which have correct background on Clinical dataset
    [Patient.tm,Patient.signal,Patient.Fs,Patient.siginfo]=rdmat(Wave(T(j)).name);
    Patient.Alive=Alive(j);
    %% Finding a special vital signal with the length more than 1 second
    Flag=0;
    for i=1:length(Patient.siginfo)
        if(strcmpi(Patient.siginfo(i).Description,'HR'))
            Flag=1;
            break
        end
    end
    
    if(Flag==0 || Patient.tm(end)<1)
        Ignored=Ignored+1;
        continue
    end
        %% dealing with NaN enteties
        Temp=isnan(Patient.signal(:,i));
        
        if (sum(Temp)>0)
            if(sum(Temp)>(length(Patient.signal(:,i))/2))
                Ignored=Ignored+1;
                continue
            end
            Input=Patient.signal(:,i);
            %Truncate the first and last NaNs
            Remove=find(cumsum(Temp')-(1:numel(Input))<0,1,'first');
            if(Remove>1)
                Input=Input(Remove:end);
            end
            
            Remove=find(((numel(Input)+1)-(1:numel(Input)))-cumsum((isnan(Input))','revers')==0,1,'first');
            if(~isempty(Remove))
                Input=Input(1:Remove-1);
            end
            % Subsitution with neighbors
            Temp=find(isnan(Input));
            for k=1:numel(Temp)
                Input(Temp(k))=Input(Temp(k)-1);
            end
        else
            Input=Patient.signal(:,i);
        end
        
    %% removing first and last zeros tails of signals
    Temp=(Input==zeros(size(Input)));
    if(sum(Temp)>1)
        Remove=find(cumsum(Temp')-(1:numel(Input))<0,1,'first');
        if(Remove>1)
            Input=Input(Remove:end);
            Temp=(Input==zeros(size(Input)));
        end
        
        Remove=find((((numel(Input)+1)-(1:numel(Input)))-cumsum(Temp','revers'))==0,1,'first');
        if(Remove>1)
            Input=Input(1:Remove-1);
        end
    end
    %% removing empety or zeros trails
    if(isempty(Input) || sum(Input)==0)
        Ignored=Ignored+1;
        continue
    end
    
    %% smoothing
    WindowsSize=find(Patient.tm>=3600,1,'first');
    if (length(Input)>=2*WindowsSize)
        Flag=1;
    else
        Flag=0;
    end
    if(isempty(WindowsSize)),WindowsSize=length(Patient.tm);end
    Patient.SmoothedSignal=smooth(Input,WindowsSize);
    %end
    Temp=Patient.SmoothedSignal;
        %% Making identical sampling rates
    if(Patient.Fs~=MaxFs)
        [P,Q] = rat(MaxFs/Patient.Fs);
        FinalSignal = resample(Temp,P,Q); 
    else
        P=1;
        FinalSignal = Temp;
    end

%         figure()
%         plot(Input, '-+b')
%         figure()
%         plot(Patient.SmoothedSignal,'-*r')
%         figure()
%         plot(FinalSignal,'-sg')

    %% Feature computation from signals
    %max, min, mean, median, mode, std, var, range, kurtosis, skewness, Energy, time, Alive
    %Patient.DescriptiveStatistics.Whole=[max(Temp), min(Temp), mean(Temp), median(Temp), mode(Temp), std(Temp), var(Temp), max(Temp)-min(Temp), kurtosis(Temp), skewness(Temp),Patient.tm(end),Patient.Alive];
    Temp=FinalSignal;
    F=F+1;
    %periodogram(Temp,[],[],MaxFs,'power')
    [Power,~]=periodogram(Temp,[],[],MaxFs,'power');
    PeriodogramPower=trapz(Power);%PeriodogramPowerSpectralDensityEstimate
    %plot(Frequency,Power)
    Whole(F,:)=[max(Temp), min(Temp), mean(Temp), median(Temp), mode(Temp), std(Temp), var(Temp), max(Temp)-min(Temp), kurtosis(Temp), skewness(Temp),Energy(Temp),PeriodogramPower,Patient.tm(end),Patient.Alive];
    if(Whole(F,1)==Whole(F,2))
        warning('The same min and max')
        warning(T(j))
    end
    if(Flag==1)
        KK=KK+1;
        Temp=FinalSignal(1:P*WindowsSize);
        [Power,~]=periodogram(Temp,[],[],MaxFs,'power');
        PeriodogramPower=trapz(Power);%PeriodogramPowerSpectralDensityEstimate
        %Patient.DescriptiveStatistics.FirstHour=[max(Temp); min(Temp); mean(Temp); median(Temp); mode(Temp); std(Temp); var(Temp); max(Temp)-min(Temp); kurtosis(Temp); skewness(Temp)];
        FirstHour(KK,:)=[max(Temp), min(Temp), mean(Temp), median(Temp), mode(Temp), std(Temp), var(Temp), max(Temp)-min(Temp), kurtosis(Temp), skewness(Temp),Energy(Temp),PeriodogramPower,Patient.Alive];
        
        Temp=FinalSignal(end-P*WindowsSize-1:end);
        %Patient.DescriptiveStatistics.LastHour=[max(Temp); min(Temp); mean(Temp); median(Temp); mode(Temp); std(Temp); var(Temp); max(Temp)-min(Temp); kurtosis(Temp); skewness(Temp)];
        [Power,~]=periodogram(Temp,[],[],MaxFs,'power');
        PeriodogramPower=trapz(Power);%PeriodogramPowerSpectralDensityEstimate
        LastHour(KK,:)=[max(Temp), min(Temp), mean(Temp), median(Temp), mode(Temp), std(Temp), var(Temp), max(Temp)-min(Temp), kurtosis(Temp), skewness(Temp),Energy(Temp),PeriodogramPower,Patient.Alive];
    end
    %sfields{j}=Patient;
end
%for i=1:length(T)
 %   Patient(i)=sfields{i};
%end
disp('Number of Ignored Signals')
disp(Ignored)
save('HRRepository','Whole','FirstHour','LastHour')